-- Customer [ent5]
create table `customer` (
   `oid`  integer  not null,
   `username`  varchar(255),
   `password`  varchar(255),
   `email`  varchar(255),
   `firstname`  varchar(255),
   `lastname`  varchar(255),
  primary key (`oid`)
);


