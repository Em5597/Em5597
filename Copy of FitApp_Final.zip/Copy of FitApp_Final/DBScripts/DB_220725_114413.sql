-- Customer_Goals [rel11]
alter table `goals_2`  add column  `customer_oid`  integer;
alter table `goals_2`   add index fk_goals_2_customer (`customer_oid`), add constraint fk_goals_2_customer foreign key (`customer_oid`) references `customer` (`oid`);


