-- AssignedTraining [ent4]
alter table `assignedtraining`  add column  `tmpinsert`  datetime;


-- Feedback [ent7]
alter table `feedback`  add column  `tmpinsert`  datetime;


-- AssignedTraining_Feedback [rel8]
alter table `feedback`  add column  `assignedtraining_oid`  integer;
alter table `feedback`   add index fk_feedback_assignedtraining (`assignedtraining_oid`), add constraint fk_feedback_assignedtraining foreign key (`assignedtraining_oid`) references `assignedtraining` (`oid`);


