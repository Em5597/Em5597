-- Video [ent1]
create table `video` (
   `oid`  integer  not null,
   `name`  varchar(255),
   `url`  varchar(255),
   `description`  varchar(255),
  primary key (`oid`)
);


-- Training [ent2]
create table `training` (
   `oid`  integer  not null,
   `name`  varchar(255),
   `description`  varchar(255),
  primary key (`oid`)
);


-- AssignedTraining [ent4]
create table `assignedtraining` (
   `oid`  integer  not null,
  primary key (`oid`)
);


-- User_AssignedTraining [rel2]
alter table `assignedtraining`  add column  `user_oid`  integer;
alter table `assignedtraining`   add index fk_assignedtraining_user (`user_oid`), add constraint fk_assignedtraining_user foreign key (`user_oid`) references `user` (`oid`);


-- Training_User [rel3]
alter table `training`  add column  `user_oid`  integer;
alter table `training`   add index fk_training_user (`user_oid`), add constraint fk_training_user foreign key (`user_oid`) references `user` (`oid`);


-- AssignedTraining_Training [rel4]
alter table `assignedtraining`  add column  `training_oid`  integer;
alter table `assignedtraining`   add index fk_assignedtraining_training (`training_oid`), add constraint fk_assignedtraining_training foreign key (`training_oid`) references `training` (`oid`);


-- Training_Video [rel5]
alter table `video`  add column  `training_oid`  integer;
alter table `video`   add index fk_video_training (`training_oid`), add constraint fk_video_training foreign key (`training_oid`) references `training` (`oid`);


