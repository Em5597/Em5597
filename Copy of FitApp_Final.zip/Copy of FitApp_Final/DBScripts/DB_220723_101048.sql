-- Customer_Feedback [rel1]
alter table `feedback`  add column  `customer_oid`  integer;
alter table `feedback`   add index fk_feedback_customer (`customer_oid`), add constraint fk_feedback_customer foreign key (`customer_oid`) references `customer` (`oid`);


