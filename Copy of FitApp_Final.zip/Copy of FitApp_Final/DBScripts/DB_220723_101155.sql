-- Customer_Evaluated [rel6]
alter table `evaluated`  add column  `customer_oid`  integer;
alter table `evaluated`   add index fk_evaluated_customer (`customer_oid`), add constraint fk_evaluated_customer foreign key (`customer_oid`) references `customer` (`oid`);


