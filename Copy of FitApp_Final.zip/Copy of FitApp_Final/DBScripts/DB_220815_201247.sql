-- AssignedTraining_Video [rel9]
alter table `assignedtraining`  add column  `video_oid`  integer;
alter table `assignedtraining`   add index fk_assignedtraining_video (`video_oid`), add constraint fk_assignedtraining_video foreign key (`video_oid`) references `video` (`oid`);


