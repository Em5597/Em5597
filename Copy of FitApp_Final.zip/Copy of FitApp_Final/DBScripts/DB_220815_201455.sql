-- AssignedTraining [ent4]
alter table `assignedtraining`  add column  `iscompleted`  integer;


