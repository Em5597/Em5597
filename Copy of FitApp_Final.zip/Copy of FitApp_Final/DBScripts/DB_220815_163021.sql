-- Log [ent5]
create table `log` (
   `oid`  integer  not null,
   `test`  varchar(255),
  primary key (`oid`)
);


