-- Evaluated [ent3]
alter table `evaluated`  add column  `insertdate`  date;


-- Goals [ent8]
alter table `goals_2`  add column  `insertdate`  date;


