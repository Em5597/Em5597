-- Training_User [rel3]
alter table `training`  add column  `user_oid`  integer;
alter table `training`   add index fk_training_user_2 (`user_oid`), add constraint fk_training_user_2 foreign key (`user_oid`) references `user` (`oid`);


-- AssignedTraining_Training [rel4]
alter table `assignedtraining`  add column  `training_oid`  integer;
alter table `assignedtraining`   add index fk_assignedtraining_training_2 (`training_oid`), add constraint fk_assignedtraining_training_2 foreign key (`training_oid`) references `training` (`training_code`);


-- Training_Video [rel5]
alter table `video`  add column  `training_oid`  integer;
alter table `video`   add index fk_video_training_2 (`training_oid`), add constraint fk_video_training_2 foreign key (`training_oid`) references `training` (`training_code`);


