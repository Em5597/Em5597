-- Feedback_Trainer [rel9]
alter table `feedback`  add column  `trainer_oid`  integer;
alter table `feedback`   add index fk_feedback_trainer (`trainer_oid`), add constraint fk_feedback_trainer foreign key (`trainer_oid`) references `trainer` (`oid`);


