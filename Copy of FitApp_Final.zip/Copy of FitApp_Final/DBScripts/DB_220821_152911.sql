-- Video [ent1]
create table `video` (
   `oid`  integer  not null,
   `name`  varchar(255),
   `video`  varchar(255),
   `description`  varchar(255),
  primary key (`oid`)
);


-- Log [ent12]
create table `log_2` (
   `oid`  integer  not null,
   `test`  varchar(255),
  primary key (`oid`)
);


-- AssignedTraining [ent4]
create table `assignedtraining` (
   `oid`  integer  not null,
   `tmpinsert`  datetime,
   `iscompleted`  integer,
  primary key (`oid`)
);


-- Feedback [ent7]
create table `feedback` (
   `oid`  integer  not null,
   `feedback`  varchar(255),
   `vote`  integer,
   `tmpinsert`  datetime,
  primary key (`oid`)
);


-- User_AssignedTraining [rel2]
alter table `assignedtraining`  add column  `user_oid`  integer;
alter table `assignedtraining`   add index fk_assignedtraining_user (`user_oid`), add constraint fk_assignedtraining_user foreign key (`user_oid`) references `user` (`oid`);


-- AssignedTraining_Training [rel4]
alter table `assignedtraining`  add column  `training_oid`  integer;
alter table `assignedtraining`   add index fk_assignedtraining_training (`training_oid`), add constraint fk_assignedtraining_training foreign key (`training_oid`) references `training` (`oid`);


-- Training_Video [rel5]
alter table `video`  add column  `training_oid`  integer;
alter table `video`   add index fk_video_training (`training_oid`), add constraint fk_video_training foreign key (`training_oid`) references `training` (`oid`);


-- AssignedTraining_Feedback [rel8]
alter table `feedback`  add column  `assignedtraining_oid`  integer;
alter table `feedback`   add index fk_feedback_assignedtraining (`assignedtraining_oid`), add constraint fk_feedback_assignedtraining foreign key (`assignedtraining_oid`) references `assignedtraining` (`oid`);


-- AssignedTraining_Video [rel9]
alter table `assignedtraining`  add column  `video_oid`  integer;
alter table `assignedtraining`   add index fk_assignedtraining_video (`video_oid`), add constraint fk_assignedtraining_video foreign key (`video_oid`) references `video` (`oid`);


