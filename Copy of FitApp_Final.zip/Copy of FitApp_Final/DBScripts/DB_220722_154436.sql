-- Feedback [ent7]
create table `feedback` (
   `oid`  integer  not null,
   `feedback`  varchar(255),
  primary key (`oid`)
);


