-- Video [ent1]
alter table `video`  add column  `description`  varchar(255);


-- Training [ent2]
alter table `training`  add column  `description`  varchar(255);


