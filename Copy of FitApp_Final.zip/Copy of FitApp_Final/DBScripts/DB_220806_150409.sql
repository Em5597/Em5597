-- Video [ent1]
alter table `video`  add column  `url`  varchar(255);


