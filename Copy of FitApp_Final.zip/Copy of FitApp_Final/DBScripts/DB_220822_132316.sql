-- Support [ent5]
alter table `support`  add column  `status`  integer;


