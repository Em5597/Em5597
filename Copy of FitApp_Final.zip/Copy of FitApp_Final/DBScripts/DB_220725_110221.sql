-- Goals [ent10]
create table `goals` (
   `oid`  integer  not null,
   `mese`  date,
   `anno`  date,
   `peso`  integer,
  primary key (`oid`)
);


-- Customer_Goals [rel10]
alter table `goals`  add column  `customer_oid`  integer;
alter table `goals`   add index fk_goals_customer (`customer_oid`), add constraint fk_goals_customer foreign key (`customer_oid`) references `customer` (`oid`);


