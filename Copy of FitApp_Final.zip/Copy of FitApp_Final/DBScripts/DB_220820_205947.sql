-- Log [ent12]
create table `log_2` (
   `oid`  integer  not null,
   `test`  varchar(255),
  primary key (`oid`)
);


-- Video [ent1]
alter table `video`  add column  `video_2`  varchar(255);


