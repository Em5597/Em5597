-- User [User]
alter table `user`  add column  `firstname`  varchar(255);
alter table `user`  add column  `lastname`  varchar(255);


