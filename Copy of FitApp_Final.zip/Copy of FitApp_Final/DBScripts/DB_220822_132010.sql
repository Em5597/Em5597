-- Support [ent5]
create table `support` (
   `oid`  integer  not null,
   `title`  varchar(255),
   `description`  varchar(255),
   `tmpinsert`  varchar(255),
  primary key (`oid`)
);


