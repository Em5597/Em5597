-- Support_User [rel1]
alter table `support`  add column  `user_oid`  integer;
alter table `support`   add index fk_support_user (`user_oid`), add constraint fk_support_user foreign key (`user_oid`) references `user` (`oid`);


