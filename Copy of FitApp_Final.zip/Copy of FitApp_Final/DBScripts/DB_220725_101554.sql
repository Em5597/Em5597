-- Trainer_Training [rel8]
create table `trainer_training` (
   `trainer_oid`  integer not null,
   `training_oid`  integer not null,
  primary key (`trainer_oid`, `training_oid`)
);
alter table `trainer_training`   add index fk_trainer_training_trainer (`trainer_oid`), add constraint fk_trainer_training_trainer foreign key (`trainer_oid`) references `trainer` (`oid`);
alter table `trainer_training`   add index fk_trainer_training_training (`training_oid`), add constraint fk_trainer_training_training foreign key (`training_oid`) references `training` (`oid`);


