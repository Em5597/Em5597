-- Log [ent5]
alter table `log`  add column  `attribute18`  varchar(255);


