-- Training [ent2]
alter table `training`  add column  `ispending`  integer;


