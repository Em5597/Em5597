-- User_Goals [rel7]
alter table `goals_2`  add column  `user_oid`  integer;
alter table `goals_2`   add index fk_goals_2_user (`user_oid`), add constraint fk_goals_2_user foreign key (`user_oid`) references `user` (`oid`);


