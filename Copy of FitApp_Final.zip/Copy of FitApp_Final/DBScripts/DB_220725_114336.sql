-- Goals [ent8]
create table `goals_2` (
   `oid`  integer  not null,
   `year`  integer,
   `month`  varchar(255),
   `weight`  integer,
  primary key (`oid`)
);


