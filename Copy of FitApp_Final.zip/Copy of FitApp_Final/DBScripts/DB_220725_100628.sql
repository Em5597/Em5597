-- Customer_Training [rel7]
create table `customer_training` (
   `customer_oid`  integer not null,
   `training_oid`  integer not null,
  primary key (`customer_oid`, `training_oid`)
);
alter table `customer_training`   add index fk_customer_training_customer (`customer_oid`), add constraint fk_customer_training_customer foreign key (`customer_oid`) references `customer` (`oid`);
alter table `customer_training`   add index fk_customer_training_training (`training_oid`), add constraint fk_customer_training_training foreign key (`training_oid`) references `training` (`oid`);


