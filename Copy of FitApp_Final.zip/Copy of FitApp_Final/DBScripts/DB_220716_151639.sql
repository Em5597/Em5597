-- Evaluated [ent3]
create table `evaluated` (
   `oid`  integer  not null,
   `weight`  decimal(19,2),
   `photo`  varchar(255),
  primary key (`oid`)
);


