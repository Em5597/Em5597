-- Feedback [ent7]
alter table `feedback`  add column  `vote`  integer;


-- User_Evaluated [rel6]
alter table `evaluated`  add column  `user_oid`  integer;
alter table `evaluated`   add index fk_evaluated_user (`user_oid`), add constraint fk_evaluated_user foreign key (`user_oid`) references `user` (`oid`);


