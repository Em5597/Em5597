-- Support [ent5]
create table `support` (
   `oid`  integer  not null,
   `title`  varchar(255),
   `description`  varchar(255),
   `tmpinsert`  datetime,
   `status`  varchar(255),
  primary key (`oid`)
);


-- Support_User [rel1]
alter table `support`  add column  `user_oid`  integer;
alter table `support`   add index fk_support_user (`user_oid`), add constraint fk_support_user foreign key (`user_oid`) references `user` (`oid`);


