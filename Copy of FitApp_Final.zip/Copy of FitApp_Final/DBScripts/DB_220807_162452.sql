-- Training_User [rel3]
alter table `training`  add column  `user_oid`  integer;
alter table `training`   add index fk_training_user (`user_oid`), add constraint fk_training_user foreign key (`user_oid`) references `user` (`oid`);


-- Training_Video [rel5]
alter table `video`  add column  `training_oid`  integer;
alter table `video`   add index fk_video_training (`training_oid`), add constraint fk_video_training foreign key (`training_oid`) references `training` (`training_code`);


