-- AssignedTraining_Training [rel4]
alter table `assignedtraining`  drop column  `training_oid`;
-- Training_User [rel3]
alter table `training`   drop foreign key `fk_training_user`;
alter table `training`  drop column  `user_oid`;
-- Training [ent2]
alter table `training`   drop column  `training_code_2`;
-- Video [ent1]
alter table `video`   drop column  `video_code_2`;
